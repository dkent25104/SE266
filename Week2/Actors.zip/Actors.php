<h1>Actors</h1><br />
<a href="Add.php">Add Actors</a>
<a href="View.php">View Actors</a>
<br /><br />
<?php


?>