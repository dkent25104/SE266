<div style='background-color:#f77f00;padding:20px 0px 5px 0px;'>
    <center>
        <nav>
            <ul style='font-size:25px;'>
                <i>
                <li><b>Country Populations</b></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="search.php">Search</a></li>
                <li><a href="region.php">Region</a></li>
                </i>
            </ul>  
        </nav>
    </center>
</div>