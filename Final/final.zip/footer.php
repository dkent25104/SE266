<div id="footer" style="position:fixed;bottom:0;background-color:#f77f00;width:100%;padding:5px 0px 0px 15%;">
    <h4><i>Dan Kent 2018</i></h4>
</div>